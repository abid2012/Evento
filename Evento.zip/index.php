<?php

  header("location: ./home");

?>